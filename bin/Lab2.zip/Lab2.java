/*Claudia Cota ID:60341850

Lab2 is the main method that constructs the CrapsSimulation object and calls start() on it to begin the game.*/

public class Lab2{
	public static void main(String[] args){
		
		CrapsSimulation craps = new CrapsSimulation();
		craps.start();
		
		
	}
	
}
